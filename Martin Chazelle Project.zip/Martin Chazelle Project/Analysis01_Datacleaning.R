# Useful packages are loaded

library (plyr)
library(ggplot2)
library(cluster)
library(lattice)
library(graphics)
library(grid)
library(gridExtra)
library(dplyr)
library(tidyr)
library(stringi)
library("stringr")
library(readxl)




############################
#---- Date Preparation -----
############################




###We need to load the data we extract from the website Cryptopanic thanks to Octoparse. 

#We have three dataset to use and can load those three

ALL <- read_excel('01_Cryptopanic_alldata.xlsx')

important <- read_excel('02_Cryptopanic_important.xlsx')

topsaved <- read_excel('03_Cryptopanic_topsaved.xlsx')
topsaved <- topsaved[-1,]




##########----------------------------
##### To be able to see the evolution in time, we need now to transform the col time_since_publication to a duration 
##########----------------------------


### First for the ALL data ###

#We haven't enought information on the exact date of publication, we can count the number of post daily in average
#Range is only 4 days and around 4-5 posts / hours
#to have tools to identify trends in very short term, we could analyse period of time of 6 hours. So 4*6 = 24
ALL$period_of_time = "new"

r <- 1
d <- 0
while (r<nrow(ALL)) {
  if(r%%24 == 0) {
    d <- d + 1
  }
  ALL$period_of_time[r] <- d 
  r <- r + 1
}


#like that we have the days since between now and the date of publications in days. 
# It will serve for data analysis. 



### Second for the important data ###

#for important data, there is on average 10 importants posts / days. 
#to learn about the market and potentially identify trends on this 2 monthes data, we could set a period of time of 4 days. So 4 days * 10 posts = 40 posts.
#times = days 
important$period_of_time = "new"

r <- 1
d <- 0
while (r<nrow(important)) {
  if(r%%30 == 0) {
    d <- d + 1
  }
  important$period_of_time[r] <- d 
  r <- r + 1
}

#We can do the same for ALL with a different scale, around 4 per hour in average




### Third for topsaved data ###

#We can do the same for topsaved with a different scale, around 4 per day in average so 28 per period in average
#times = days 

topsaved$period_of_time = "new"

r <- 1
d <- 0
while (r<nrow(topsaved)) {
  if(r%%28 == 0) {
    d <- d + 1
  }
  topsaved$period_of_time[r] <- d 
  r <- r + 1
}


##########----------------------------
##### We can transform the sources and coins col to be able to do some plots  
##########----------------------------

ALL$Sources <- as.factor(ALL$Sources)
ALL$Coin1 <- as.factor(ALL$Coin1)

important$Sources <- as.factor(important$Sources)
important$Coin1 <- as.factor(important$Coin1)

topsaved$Sources <- as.factor(topsaved$Sources)
topsaved$Coin1 <- as.factor(topsaved$Coin1)

summary(ALL)
summary(important)
summary(topsaved)
