#useful packages

library (plyr)
library(ggplot2)
library(cluster)
library(lattice)
library(graphics)
library(grid)
library(gridExtra)
library(dplyr)
library(tidyr)
library(stringi)
library("stringr")
library(readxl)



#########################################
#---Corpus creation and data cleaning---#
#########################################

### Creation of a function to transform our different df of posts

preprocess_text <- function(text) {
  usableText <- iconv(text, to = "ASCII", sub="")
  corpus <- Corpus(VectorSource(usableText))
  corpus <- tm_map(corpus, tolower)
  corpus <- tm_map(corpus, removePunctuation)
  corpus <- tm_map(corpus, removeNumbers)
  corpus <- tm_map(corpus, function(x) removeWords(x, stopwords()))
  corpus <- tm_map(corpus, function(x) removeWords(x, stopwords("french")))
  corpus <- tm_map(corpus, function(x) removeWords(x, stopwords("italian")))
  corpus <- tm_map(corpus, function(x) removeWords(x, stopwords("spanish")))
  return(corpus)
}

### First for the BTC data ###
BTC_corpus <- preprocess_text(BTC$Posts)

### Second for the ADA data ###
ADA_corpus <- preprocess_text(ADA$Posts)



#########################################################
#--------Process and vizualize with clustering----------#
#########################################################



preprocess_and_visualize <- function(corpus, color, title, title_bp) {
  text_corpus <- tm_map(corpus, content_transformer(function(x) iconv(x,to='ASCII',sub='byte')))
  
  Matrix.tdm <- TermDocumentMatrix(text_corpus)
  m <- as.matrix(Matrix.tdm)
  
  v <- sort(rowSums(m),decreasing=TRUE)
  d <- data.frame(word = names(v),freq=v)
  
  barplot(d[1:20,]$freq, las = 3, names.arg = d[1:20,]$word,
          col = color, main = title_bp,
          ylab = "Word frequencies")
  
  wordcloud(words = d$word, freq = d$freq, min.freq = 40, max.words=100,
            random.order=FALSE, colors=brewer.pal(4,"Dark2"))
  
  Matrix.tdm<-removeSparseTerms(Matrix.tdm, sparse=0.95)
  Matrix.df <- as.data.frame(as.matrix(Matrix.tdm))
  Matrix.df.scale <- scale(Matrix.df)
  Matrix.dist <- dist(Matrix.df.scale,
                          method = "euclidean")
  Matrix.fit<-hclust(Matrix.dist, method="ward.D2")
  
  groups <- cutree(Matrix.fit, k=5)
  plot(Matrix.fit, main=title)
  rect.hclust(Matrix.fit, k=5, border="red")
}


### First for the BTC data ###
BTC_visualize <- preprocess_and_visualize(BTC_corpus, "darkgoldenrod1", "BTC - Clustering", "Most frequent words - BTC")

### Second for the ADA data ###
ADA_visualize <- preprocess_and_visualize(ADA_corpus, "cornflowerblue", "ADA - Clustering", "Most frequent words - ADA")




##########################
#-- Sentiment analysis 
##########################


calculate_sentiment <- function(data, data_corpus){
  plain.text <- vector()
  for(i in 1:dim(data)[1]){
    plain.text[i] <- data_corpus[[i]][[1]]
  }
  sentence_sentiment <- sentiment(get_sentences(plain.text))
  average_sentiment <- mean(sentence_sentiment$sentiment)
  sd_sentiment <- sd(sentence_sentiment$sentiment)
  return(list(sentence_sentiment = sentence_sentiment,
              average_sentiment = average_sentiment,
              sd_sentiment = sd_sentiment))
}


### First for the important data ###
BTC_sentiment <- calculate_sentiment(BTC, BTC_corpus)

### Second for the ALL data ###$
ADA_sentiment <- calculate_sentiment(ADA, ADA_corpus)




########################################
#  Sentiment Average - Period of Time
########################################

#Adding sentiment col to the three dataframe

BTC$sentiment <- BTC_sentiment$sentence_sentiment$sentiment
ADA$sentiment <- ADA_sentiment$sentence_sentiment$sentiment

#function that will create the sentiment plot. The x axis is reverse, more we go on right more far we are.

plot_mean_sentiment <- function(data, title,xlab,ylab,color) {
  agg_tbl <- data %>% group_by(period_of_time) %>% 
    summarise(mean_sentiment=mean(sentiment),
              .groups = 'drop')
  
  ggplot(agg_tbl, aes(period_of_time, mean_sentiment, fill = color)) +
    geom_col(show.legend = FALSE) +
    ggtitle(title) +
    xlab(xlab) +
    ylab(ylab) +
    theme_classic()
}

##Using the new function

### First for the important data ###
plot_mean_sentiment(BTC, "Sentiment BTC data analysis", "Reverse time", "Sentiment" , "darkgoldenrod1")

### Second for the ALL data ###$
plot_mean_sentiment(ADA, "Sentiment ADA data analysis", "Reverse time", "Sentiment" , "cornflowerblue")


