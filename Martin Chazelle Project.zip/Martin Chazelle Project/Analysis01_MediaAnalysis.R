
library (plyr)
library(ggplot2)
library(cluster)
library(lattice)
library(graphics)
library(grid)
library(gridExtra)
library(dplyr)
library(tidyr)
library(stringi)
library("stringr")
library(readxl)
library(wordcloud)
library(sentimentr)
library("tm")


#################
#  barplot for each crypto
#################


visualize_crypto_count <- function(data, color, title) {
  data %>% count(Coin1, sort = TRUE) %>%
    mutate(Coin1=reorder(Coin1,n)) %>%
    na.omit() %>% top_n(10) %>%
    ggplot(aes(x=Coin1,y=n)) +
    geom_bar(stat="identity", fill = color, color = "white", size = 0.3) +
    coord_flip() +
    labs(x = "Cryptocurrencies", y = "Count",
         title = title,
         subtitle = "Top 10 most frequent coins") +
    theme_minimal()+
    theme(axis.text.x = element_text(size = 14, angle = 90, hjust=1, vjust=0.5, color=color),
          axis.text.y=element_text(color=color),
          axis.title.x=element_text(color=color),
          axis.title.y=element_text(color=color),
          plot.title=element_text(color=color))
}

### First for the ALL data ###
visualize_crypto_count(ALL, "steelblue2", "Count of top cryptocurrencies in ALL data")

### Second for the important data ###
visualize_crypto_count(important, "steelblue3", "Count of top cryptocurrencies in important data")

### Third for topsaved data ###
visualize_crypto_count(topsaved, "steelblue4", "Count of top cryptocurrencies in topsaved data")



#########################################
#---Corpus creation and data cleaning---#
#########################################

### Creation of a function to transform our different df of posts

preprocess_text <- function(text) {
  usableText <- iconv(text, to = "ASCII", sub="")
  corpus <- Corpus(VectorSource(usableText))
  corpus <- tm_map(corpus, tolower)
  corpus <- tm_map(corpus, removePunctuation)
  corpus <- tm_map(corpus, removeNumbers)
  corpus <- tm_map(corpus, function(x) removeWords(x, stopwords()))
  corpus <- tm_map(corpus, function(x) removeWords(x, stopwords("french")))
  corpus <- tm_map(corpus, function(x) removeWords(x, stopwords("italian")))
  corpus <- tm_map(corpus, function(x) removeWords(x, stopwords("spanish")))
  return(corpus)
}

### First for the ALL data ###
ALL_corpus <- preprocess_text(ALL$Posts)

### Second for the important data ###
important_corpus <- preprocess_text(important$Posts)

### Third for topsaved data ###
topsaved_corpus <- preprocess_text(topsaved$Posts)




#########################################
#--------Process and vizualize----------#
#########################################


preprocess_and_visualize <- function(corpus, color, title) {
  text_corpus <- tm_map(corpus, content_transformer(function(x) iconv(x,to='ASCII',sub='byte')))
  
  Matrix.tdm <- TermDocumentMatrix(text_corpus)
  m <- as.matrix(Matrix.tdm)
  
  v <- sort(rowSums(m),decreasing=TRUE)
  d <- data.frame(word = names(v),freq=v)
  
  barplot(d[1:20,]$freq, las = 3, names.arg = d[1:20,]$word,
          col = color, main = title,
          ylab = "Word frequencies")
  
  wordcloud(words = d$word, freq = d$freq, min.freq = 30, max.words=100,
            random.order=FALSE, colors=brewer.pal(4,"Dark2"))
}



### First for the ALL data ###
ALL_visualize <- preprocess_and_visualize(ALL_corpus, "steelblue2", "Most frequent words - ALL data")

### Second for the important data ###
important_visualize <- preprocess_and_visualize(important_corpus, "steelblue3", "Most frequent words - important data")

### Third for topsaved data ###
topsaved_visualize <- preprocess_and_visualize(topsaved_corpus, "steelblue4", "Most frequent words - topsaved data")





##########################
#-- Sentiment analysis 
##########################


calculate_sentiment <- function(data, data_corpus){
  plain.text <- vector()
  for(i in 1:dim(data)[1]){
    plain.text[i] <- data_corpus[[i]][[1]]
  }
  sentence_sentiment <- sentiment(get_sentences(plain.text))
  average_sentiment <- mean(sentence_sentiment$sentiment)
  sd_sentiment <- sd(sentence_sentiment$sentiment)
  return(list(sentence_sentiment = sentence_sentiment,
              average_sentiment = average_sentiment,
              sd_sentiment = sd_sentiment))
}


### First for the important data ###
ALL_sentiment <- calculate_sentiment(ALL, ALL_corpus)

### Second for the ALL data ###$
important_sentiment <- calculate_sentiment(important, important_corpus)

### Third for topsaved data ###
topsaved_sentiment <- calculate_sentiment(topsaved, topsaved_corpus)




########################################
#  Sentiment Average - Period of Time
########################################

#Adding sentiment col to the three dataframe

ALL$sentiment <- ALL_sentiment$sentence_sentiment$sentiment
important$sentiment <- important_sentiment$sentence_sentiment$sentiment
topsaved$sentiment <- topsaved_sentiment$sentence_sentiment$sentiment

#function that will create the sentiment plot. The x axis is reverse, more we go on right more far we are.

plot_mean_sentiment <- function(data, title,xlab,ylab,color) {
  agg_tbl <- data %>% group_by(period_of_time) %>% 
    summarise(mean_sentiment=mean(sentiment),
              .groups = 'drop')
  
  ggplot(agg_tbl, aes(period_of_time, mean_sentiment, fill = color)) +
    geom_col(show.legend = FALSE) +
    ggtitle(title) +
    xlab(xlab) +
    ylab(ylab) +
    theme_classic()
}

##Using the new function

### First for the important data ###
plot_mean_sentiment(ALL, "Sentiment ALL data analysis", "Reverse time", "Sentiment" , "steelblue2")

### Second for the ALL data ###$
plot_mean_sentiment(important, "Sentiment important data analysis", "Reverse time", "Sentiment" , "steelblue3")

### Third for topsaved data ###
plot_mean_sentiment(topsaved, "Sentiment topsaved data analysis", "Reverse time", "Sentiment" , "steelblue4")


