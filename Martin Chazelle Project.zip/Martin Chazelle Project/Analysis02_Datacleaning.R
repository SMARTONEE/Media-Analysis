# Useful packages are loaded

library (plyr)
library(ggplot2)
library(cluster)
library(lattice)
library(graphics)
library(grid)
library(gridExtra)
library(dplyr)
library(tidyr)
library(stringi)
library("stringr")
library(readxl)




############################
#---- Date Preparation -----
############################




###We need to load the data we extract from the website Cryptopanic thanks to Octoparse. 

#We have three dataset to use and can load those three


BTC <- read_excel('04_Cryptopanic_bitcoinanalysis.xlsx')

ADA <- read_excel('05_Cryptopanic_cardanoanalysis.xlsx')




##########----------------------------
##### To be able to see the evolution in time, we need now to transform the col time_since_publication to a duration 
##########----------------------------


### First for the BTC data ###

#We haven't enought information on the exact date of publication, we can count the number of post daily in average
#Range is 6 months and around 4-5 posts / day.

#to have tools to identify trends in very mid term, we could analyse period of time of a week hours. So 4 posts * 7 days = 28
BTC$period_of_time = "new"

r <- 1
d <- 0
while (r<nrow(BTC)) {
  if(r%%28 == 0) {
    d <- d + 1
  }
  BTC$period_of_time[r] <- d 
  r <- r + 1
}


#like that we have the days since between now and the date of publications in days. 
# It will serve for data analysis. 



### Second for the ADA data ###

#for ADA data, there is on average  3 posts / days. 
#to learn about the market and potentially identify trends on this 7 monthes of data, we could set a period of time of one week. So 7 days * 3 posts = 21 posts.
#times = days 
ADA$period_of_time = "new"

r <- 1
d <- 0
while (r<nrow(ADA)) {
  if(r%%30 == 0) {
    d <- d + 1
  }
  ADA$period_of_time[r] <- d 
  r <- r + 1
}



##########----------------------------
##### We can transform the sources and coins col to be able to do some plots  
##########----------------------------

BTC$Sources <- as.factor(BTC$Sources)
BTC$Coin <- as.factor(BTC$Coin)

ADA$Sources <- as.factor(ADA$Sources)
ADA$Coin <- as.factor(ADA$Coin)




